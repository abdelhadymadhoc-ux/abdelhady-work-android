abdelhady.work — مشروع Android APK

هذا مشروع Android بسيط يفتح الموقع https://abdelhady.work داخل تطبيق مستقل باستخدام WebView.
اسم التطبيق: abdelhady.work
معرّف التطبيق: com.abdelhady.work

مهم:
- هذا ملف مشروع مصدر، وليس APK جاهزًا للتثبيت.
- يتطلب بناء APK عبر Android Studio أو GitHub Actions.
- البناء عبر GitHub Actions:
  1) ارفع محتويات هذا المجلد إلى مستودع GitHub جديد.
  2) افتح تبويب Actions.
  3) شغّل Build Android APK (أو انتظر تشغيله بعد رفع الملفات).
  4) افتح عملية البناء الناجحة ثم نزّل Artifact باسم abdelhady-work-apk.
  5) فك ضغط الـ Artifact على الموبايل وثبّت app-debug.apk.
- التطبيق يحتاج الإنترنت لفتح الموقع المنشور.
- راجع صلاحيات وسياسات الموقع قبل توزيع التطبيق على أشخاص آخرين.
